//
//  SearchResponse.swift
//  Lab 3
//
// Joaquin Bala
//

import Foundation

struct SearchResponse: Codable {
    let search: [Movie]

    enum CodingKeys: String, CodingKey {
        case search = "Search"
    }
}

struct Movie: Codable {
    let title: String
    let year: Int
    let imdbID: String
    let poster: String

    init(title: String, year: Int, imdbID: String, poster: String) {
        self.title = title
        self.year = year
        self.imdbID = imdbID
        self.poster = poster
    }

    enum CodingKeys: String, CodingKey {
        case title = "Title"
        case year = "Year"
        case imdbID
        case poster = "Poster"
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.title = try container.decode(String.self, forKey: .title)
        self.year = Int(try container.decode(String.self, forKey: .year)) ?? 0
        self.imdbID = try container.decode(String.self, forKey: .imdbID)
        self.poster = try container.decode(String.self, forKey: .poster)
    }
}
